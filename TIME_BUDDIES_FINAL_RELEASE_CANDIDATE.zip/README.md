# TIME BUDDIES — FINAL RELEASE CANDIDATE

**Mission: Save the Fun World**

This package is the final source/release-candidate package for the current TIME BUDDIES scope. It is offline-first and does not require an account or server for gameplay.

## Included gameplay
- Modern portrait runner presentation
- Swipe anywhere: left/right lane change, up jump, down slide
- Small JUMP and SPECIAL controls only; no on-screen D-pad
- Double-tap jump
- 6 heroes with coin unlocks
- 8 Robo Buddies with different gameplay abilities; one equipped Robo follows during a run
- 7 worlds with progressive unlocks
- Coins, gems, score, distance and combo progression
- Obstacles, speed pickups and multi-hit boss encounters
- Time special with charging meter
- Shield, magnet, speed and jump upgrades
- 5 pets and 5 boards with unlock/equip flow
- Daily mission reset, mission rewards and collection screen
- Local progress save on device
- Haptic feedback where supported
- Offline cache/service worker for the web build

## Release packaging
The `android/` folder is a native Android WebView wrapper containing the game in `app/src/main/assets/www/`.

The package is **not a pre-signed APK/AAB**. A genuine release signature must be created with the owner's keystore on the device/build environment used for publication. This workspace does not contain the Android SDK/build tools or the owner's signing key, so it would be unsafe and misleading to claim a Play-ready signed AAB was produced here.

## What remains for the owner
1. Open the `android/` project in an Android IDE that supports Gradle/Android SDK.
2. Let Gradle sync and install/build dependencies.
3. Build a **signed release AAB** with the owner's private upload key.
4. Install the release build on the phone and test it before upload.
5. In Play Console, complete the developer account, app content, target audience, Data Safety, content rating, store listing and testing/release forms.
6. Upload the signed AAB and submit for review.

## Current privacy/data behavior
The current game stores progression locally in browser/WebView storage. It does not contain an ad SDK, analytics SDK, login, cloud sync, or remote account system. If ads, analytics, purchases, or cloud services are added later, the privacy policy and Play Data Safety answers must be updated before that release.

## Store assets
`store-assets/` contains the supplied visual-direction artwork, an icon and feature-graphic drafts. The preview images are design references and should not be submitted as gameplay screenshots unless they accurately represent the installed build.
