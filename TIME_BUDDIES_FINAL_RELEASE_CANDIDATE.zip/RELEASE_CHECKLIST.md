# TIME BUDDIES Release Checklist

## Build
- [ ] Open `android/` in Android IDE.
- [ ] Gradle sync succeeds.
- [ ] Debug build installs and launches.
- [ ] Release build installs and launches.
- [ ] Signed release AAB created with publisher-owned key.

## Device QA
- [ ] Portrait phone test.
- [ ] Small screen test.
- [ ] Large screen test.
- [ ] Android 10 test (target device).
- [ ] Swipe left/right works anywhere.
- [ ] Swipe up jump works.
- [ ] Swipe down slide works.
- [ ] JUMP and SPECIAL buttons do not cover the play area.
- [ ] Pause/resume works.
- [ ] Bosses can be cleared.
- [ ] Coins/gems/progression save after closing and reopening.
- [ ] Reset progress works.
- [ ] Offline launch works after first install.

## Play Console
- [ ] Developer account completed.
- [ ] App name/package checked.
- [ ] Store icon uploaded.
- [ ] Real screenshots from the release build uploaded.
- [ ] Feature graphic prepared according to current Play requirements.
- [ ] App category selected.
- [ ] Content rating completed.
- [ ] Target audience/child-directed declarations completed accurately.
- [ ] Data Safety completed from the final build.
- [ ] Privacy-policy URL added if required.
- [ ] Testing/release track completed.
- [ ] Signed AAB uploaded.
- [ ] Review submitted.
