# TIME BUDDIES — Play Store Listing Draft

## App title
TIME BUDDIES

## Short description
Swipe, jump and save the Fun World with heroes, Robo Buddies and time powers.

## Full description
TIME BUDDIES is a fast, colorful action runner built around simple modern touch controls.

Swipe anywhere on the screen to move left or right. Swipe up to jump and swipe down to slide. Keep the screen clean with only small JUMP and SPECIAL buttons visible.

### Build your Time Team
• Choose from 6 heroes and unlock more with coins.
• Collect 8 different Robo Buddies. Equip one and let it follow you during every run.
• Explore 7 worlds, each with its own visual theme and progression.
• Collect coins and gems while improving your best score.

### Power up
• Time Freeze special
• Speed Boost
• Shield protection
• Magnet upgrades
• Jump upgrades
• Boards and companion pets

### Play your way
• Offline-first gameplay
• Local progress save
• Daily missions and rewards
• Collection/progression system
• Kid-friendly, no-blood action

TIME BUDDIES is designed for quick sessions and simple controls while leaving room for future content updates.

## Current monetization status
This release candidate does not include an advertising SDK or in-app purchase system. Monetization can be added in a later version with the required Play Console declarations and updated privacy/data-safety information.
