# Google Play Data Safety — current build guidance

For the current source as packaged here:

- No account creation/login.
- No developer server/database.
- No advertising SDK.
- No analytics SDK.
- No in-app purchase SDK.
- Gameplay progression is stored locally on the device.

The exact Play Console Data Safety answers must be completed by the publisher based on the final APK/AAB actually uploaded. If any SDK or network service is added, re-check every answer.
