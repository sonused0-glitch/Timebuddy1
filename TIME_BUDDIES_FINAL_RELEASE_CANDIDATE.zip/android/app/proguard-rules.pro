# TIME BUDDIES release rules. No custom shrinking rules required for the WebView wrapper.
