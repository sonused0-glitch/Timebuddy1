# TIME BUDDIES Privacy Policy — Current Release Candidate

**Last updated:** 2026-08-31

TIME BUDDIES, in this current release candidate, is an offline-first game. The game does not require an account and does not collect or transmit personal information to a developer server.

## Data stored on the device
Game progress such as coins, gems, selected hero, selected Robo Buddy, unlocked content, upgrades and mission progress is stored locally on the device using app/browser storage.

## Network services
The current release candidate does not include login, cloud sync, advertising SDKs, analytics SDKs, or in-app purchase SDKs.

## Children
The game is designed with simple, non-graphic action and kid-friendly presentation. Parents/guardians should supervise device and Play Store settings appropriate to the child.

## Changes
If a future update adds ads, analytics, purchases, cloud sync, account login, or other data processing, this policy must be updated before that functionality is released.

## Contact
Before publishing, replace this section with the developer/publisher contact email required for the final public privacy-policy page.
